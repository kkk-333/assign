import java.lang.*;
import java.util.*;

public class Assignment2Q4 {

	public static void main(String[] args) {

		B obj1=new B();
		obj1.fun1();
		obj1.fun2();

		D obj2=new D();

		F obj3=new F();
	}

}



abstract class A {           
  public abstract void fun1();
  public void fun2() {
    System.out.println("abstract class");
  }
}


class B extends A{public void fun1(){System.out.println("B class");}}

abstract class C extends A{   
	public void fun3(){System.out.println("C class");}
}

class D extends C{public void fun1(){System.out.println("D class");}}




abstract class E{             
	public void fun4(){System.out.println("e class");}
} 

class F extends E{public void fun5(){System.out.println("F class");}}



